#define MYFILEVER        3,1,0,15
#define MYPRODUCTVER     3,1,0,15
#define MYSTRFILEVER     "3, 1, 0, 15\0"
#define MYSTRPRODUCTVER  "3, 1, 0, 15\0"
