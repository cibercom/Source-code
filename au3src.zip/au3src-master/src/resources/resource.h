//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by AutoIt.rc
//
#define IDS_AUT_E_TITLE                 101
#define IDS_AUT_E_OBJECTALLOC           102
#define IDS_AUT_E_OPENSCRIPT            103
#define IDS_AUT_E_BADFUNCSTATEMENT      104
#define IDS_AUT_TIP_PAUSED              105
#define IDS_AUT_E_GENPARSE              106
#define IDS_AUT_E_RIGHTPAREN            107
#define IDS_AUT_E_MISSINGOP             108
#define IDS_AUT_E_UNBALANCEDPAREN       109
#define IDS_AUT_E_EXPRESSION            110
#define IDS_AUT_E_GENFUNCTION           111
#define IDS_AUT_E_FUNCTIONNUMPARAMS     112
#define IDS_AUT_E_REDIMUSEDONNONARRAY   113
#define IDS_AUT_E_EXTRAONLINE           114
#define IDS_AUT_E_MISSINGENDIF          115
#define IDS_AUT_E_ELSENOMATCHINGIF      116
#define IDS_AUT_E_ENDIFNOMATCHINGIF     117
#define IDS_AUT_E_TOOMANYELSE           118
#define IDS_AUT_E_MISSINGWEND           119
#define IDS_AUT_E_WENDNOMATCHINGWHILE   120
#define IDS_AUT_E_VARNOTFOUND           121
#define IDS_AUT_E_BADSUBSCRIPT          122
#define IDS_AUT_E_PARSESUBSCRIPT        123
#define IDS_AUT_E_NONARRAYWITHSUBSCRIPT 124
#define IDS_AUT_E_TOOMANYSUBSCRIPTS     125
#define IDS_AUT_E_TOOFEWSUBSCRIPTS      126
#define IDS_AUT_E_DIMWITHOUTVAR         127
#define IDS_AUT_E_EXPECTEDASSIGNMENT    128
#define IDS_AUT_E_INVALIDSTARTKEYWORD   129
#define IDS_AUT_E_ARRAYALLOC            130
#define IDS_AUT_E_MISSINGENDFUNC        131
#define IDS_AUT_E_DUPLICATEFUNC         132
#define IDS_AUT_E_UNKNOWNUSERFUNC       133
#define IDS_AUT_E_MACROUNKNOWN          134
#define IDS_AUT_E_RUNPROG               135
#define IDE_AUT_E_PROCESSNT             136
#define IDS_AUT_E_EXITWHILE             138
#define IDS_AUT_E_BADOPTION             139
#define IDS_AUT_E_URLMON                140
#define IDS_AUT_E_ARRAYUSEDNODIM        141
#define IDS_AUT_E_TOOMANYFILES          142
#define IDS_AUT_E_FILEHANDLEINVALID     143
#define IDS_AUT_E_BADFILEFILTER         144
#define IDS_AUT_E_FUNCTIONEXPECTEDVARIABLE 145
#define IDS_AUT_E_MISSINGUNTIL          146
#define IDS_AUT_E_UNTILNOMATCHINGDO     147
#define IDS_AUT_E_NEXTNOMATCHINGFOR     149
#define IDS_AUT_E_EXITLOOP              150
#define IDS_AUT_E_MISSINGNEXT           151
#define IDS_AUT_E_CASENOMATCHINGSELECT  152
#define IDS_AUT_E_ENDSELECTNOMATCHINGSELECT 153
#define IDS_AUT_E_MAXRECURSE            154
#define IDS_AUT_E_RUNASFAILED           155
#define IDS_AUT_E_MISSINGQUOTE          156
#define IDS_AUT_E_EXPANDENV             157
#define IDS_AUT_E_VARBADFORMAT          158
#define IDS_AUT_E_FORERROR              159
#define IDS_AUT_E_MISSINGENDSELECTORCASE 160
#define IDI_MAIN                        161
#define IDS_AUT_E_MISSINGTHEN           162
#define IDS_AUT_E_NESTEDIF              163
#define IDI_PAUSED                      164
#define IDS_AUT_E_KEYWORDAFTERTHEN      165
#define IDR_TRAY1                       166
#define ID_TRAY_PAUSE                   167
#define IDS_AUT_E_ASSIGNTOCONST         167
#define ID_EXIT                         168
#define IDS_AUT_E_CONSTONEXISTING       168
#define IDI_DRAG                        169
#define IDD_INPUTBOX                    1000
#define IDC_INPUTEDIT                   1001
#define IDC_INPUTPROMPT                 1002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        170
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           301
#endif
#endif
