#!/bin/sh
rosservice call /mower_service/emergency "emergency: 0"
