# Mower Simulation

The purpose of this package is to allow simulating an OpenMower on your PC without any additional hardware.

The simulated mower subscribes to the same topics as the real mower and publishes the same data. It basically replaces the mower_comms node.

In order to use the simulation, use the included launch file.
