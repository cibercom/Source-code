#!/bin/sh
rosservice call /mower_service/high_level_control "command: 4"
